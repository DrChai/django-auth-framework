class AuthFrameworkAuthException(Exception):
    pass


class AuthFrameworkImproperlyConfigured(AuthFrameworkAuthException):
    pass