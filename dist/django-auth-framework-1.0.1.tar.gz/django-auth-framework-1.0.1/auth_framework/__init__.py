import pkg_resources


# __version__ = pkg_resources.require("django-auth-framework")[0].version
__version__ = '1.0.1'
